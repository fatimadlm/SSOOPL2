#ifndef REDIRECCIONES_H
#define REDIRECCIONES_H
void redirec_entrada(char **args, int indice_entrada, int *entrada);
void redirec_salida(char **args, int indice_salida, int *salida);
#endif
